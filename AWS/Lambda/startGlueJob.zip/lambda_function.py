import boto3
import json

glue_client = boto3.client('glue')

def lambda_handler(event, context):
    # # Extract S3 event details
    # s3_bucket = event['Records'][0]['s3']['bucket']['name']
    # s3_key = event['Records'][0]['s3']['object']['key']
    
    # Print details (optional, for debugging)
    # print(f'File uploaded to {s3_bucket}/{s3_key}')
    
    # Trigger Glue job (replace with your job name)
    glue_response = glue_client.start_job_run(
        JobName='Reddit_glue_job'
    )
    print(f'Glue job started: {glue_response}')
    
    return {
        'statusCode': 200,
        'body': json.dumps('Job triggered successfully')
    }
