import boto3
import json

sns_client = boto3.client('sns')

def send_email(message, subject):
    sns_client.publish(
        TopicArn="arn:aws:sns:us-east-1:438465132279:lambdastatus",
        Message=message,
        Subject=subject
    )

def lambda_handler(event, context):
    # Simulate success/failure (in reality, this should be based on job status)
    success_message = "The pipeline ran successfully and data was loaded into GlueJ."
    failure_message = "The pipeline failed at some point. Please check the logs."

    is_success = True  # This should be determined based on job status

    if is_success:
        send_email(success_message, "Pipeline Success")
    else:
        send_email(failure_message, "Pipeline Failure")

    return {'statusCode': 200, 'body': 'Email sent successfully'}
