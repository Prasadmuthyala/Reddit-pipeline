import boto3
import json
import logging

# Initialize SNS client
sns_client = boto3.client('sns')

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def send_email(message, subject):
    sns_client.publish(
        TopicArn="arn:aws:sns:us-east-1:438465132279:lambdastatus",  # Make sure to use your actual SNS ARN
        Message=message,
        Subject=subject
    )

def lambda_handler(event, context):
    try:
        # Log the received event for debugging
        logger.info(f"Received event: {json.dumps(event)}")
        
        # Extract job state from event
        job_name = event['detail']['jobName']
        job_state = event['detail']['state']

        # Determine the message based on the Glue job's state
        if job_state == "SUCCEEDED":
            success_message = f"The Glue job '{job_name}' has completed successfully."
            send_email(success_message, "Glue Job Success")
        elif job_state == "FAILED":
            failure_message = f"The Glue job '{job_name}' has failed. Please check the logs for more details."
            send_email(failure_message, "Glue Job Failure")


        return {
            'statusCode': 200,
            'body': json.dumps(f'Notification sent for job: {job_name} with status: {job_state}')
        }
    except KeyError as e:
        logger.error(f"Missing expected field in the event: {str(e)}")
        return {
            'statusCode': 400,
            'body': json.dumps(f"Error: Missing expected field in the event: {str(e)}")
        }
    except Exception as e:
        logger.error(f"Unexpected error occurred: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error: {str(e)}")
        }
